<?php

defined( 'ABSPATH' ) or die( 'You cannot access this script directly' );
if(!defined('PMC_SHOP')) define( 'PMC_SHOP', false );

/*importer*/
	
	function pmc_importer() { ?>
		
		<div id="pmc-importer" class="wrap">
	
            <h2>THEME DATA IMPORTER</h2>

            
			<?php 
			
			/*
			|--------------------------------------------------------------------------
			| Notifications
			|--------------------------------------------------------------------------
			*/
			if( file_exists( ABSPATH . 'wp-content/uploads/' ) ) {
				
				/* wp-content upload folder not writeable  */ 
				if( !pmc_check_folder( ABSPATH . 'wp-content/uploads/' ) ) :
				
					echo '<div class="error"><p>';
						
						echo '<strong>Your upload folder is not writeable! The importer won\'t be able to import the placeholder images. Please check the folder permissions for</strong><br />';
						echo ABSPATH . 'wp-content/uploads/';
						
					echo '</p></div>';
					
				endif;
				
			
			} else {
			
				/* wp-content folder not writeable  */ 
				if( !pmc_check_folder( ABSPATH . 'wp-content/uploads/' ) ) :
					
					echo '<div class="error"><p>';
					
						echo '<strong>Your wp-content folder is not writeable! The importer won\'t be able to import the placeholder images. Please check the folder permissions for</strong><br />';
						echo ABSPATH . 'wp-content/';
					
					echo '</p></div>';
					
				endif;
			
			}
			
			
			/* importer has been used before */
			if( get_option('pmc-import-exist') == 'true' ) :
				
				echo '<div class="error"><p>You already have imported the demo content before. Running this operation twice will result in double content!</p></div>';
			
			endif;
			
			/* import was successful */
			if( isset($_GET['pmc-import-success']) && $_GET['pmc-import-success'] == 'success' ) : 
				
				echo '<div class="updated"><p>Import was successful, have fun!</p></div>';
			
			endif; 

			if ( ! class_exists('Widget_Data_PMC') ) { 
				$class_widget_import = AQPB_PATH . 'assets/import/plugins/class-widget-data.php';
				if ( file_exists( $class_widget_import ) ) {
					include $class_widget_import;
				}
				
			}			
			
			?>
			<div class = "pmc-importer-notes">
				<h4>IMPORTANT - READ FIRST</h4>
			</div>
                <ol>
                    <li>We recommend you run our import on a clean WordPress installation to avoid unnecessary complications.</li>
					 <li>All of your posts and pages will be deleted, so use this only on clean install !!!!</li>
                    <li>To reset your installation we recommend the following plugin: <a href="http://wordpress.org/plugins/wordpress-database-reset/">Wordpress Database Reset</a></li>
                    <li>Never run the importer more then once as it will result in extra (double) content.</li>
					<li>If you have any doubts whether you should run importer or not, do not hesitate to <a target="_blank" href = "https://premiumcoding.zendesk.com/anonymous_requests/new">contact us.</a></li>
                </ol>
			
            
            <form id="pmc-import" method="POST" action="?page=pmc_importer">
            
            <div class="import-theme">
                <label class="pmc-choose-demo-img" for="pmc_file_one">
                    <a target="_blank" title="Barber Theme Preview" href="http://ecorecycle.premiumcoding.com/" ><img src="<?php echo plugins_url() ?>/page-builder-pmc/assets/import/images/pmc-preview.jpg" /></a>                
                </label>
				<div class = "import-theme-title">
					<input type="radio" id="pmc_file_one" name="pmc_file" value="pmc_file_one" checked class="pmc-demo-file-select">
					<h3 span="import-theme-name">Eco theme</h3>
					<div class="import-theme-actions">
						<a target="_blank" href="http://ecorecycle.premiumcoding.com/" class="button button-primary">Preview</a>
					</div>
				</div>           
            </div>
    

			
            <div class="pmc-importer-options">
            
            <div class="form-table">
            	
                <div class ="pmc-rev-slider-import-title">
					<h3>REVOLUTION SLIDER</h3>
					<p class="widget-selection-error">*Theme comes with Revolution Slider. Check the box below if you wish to import it.</p>
				</div>
				<div class="pmc-rev-slider-import">  
					 <input type="checkbox" value="yes" checked id="pmc-import-revslider" name="pmc-import-revslider">
						Import Revolution Sliders?
                </div>     
                    <?php
					$file_widget = AQPB_DIR . 'assets/import/widget/widget.json';
					$class_widget_import = new Widget_Data_PMC();
					$class_widget_import->import_settings_page($file_widget);					
					?>
            </div>
            
            </div>
            
            <div class="pmc-import-bar">
                
                <input type="hidden" name="pmc_import_demo" value="true" />
                <input type="submit" value="Import" class="button button-primary" id="submit" name="submit">
                
            </div>
            
           </form>
		
		</div>
		
	<?php }
	

/*import files - let the fun begin :) */
add_action( 'admin_init', 'pmc_file_import' );

	function pmc_file_import() {
		
		global $wpdb;
	
		/* add option flag to wordpress */
		add_option('pmc-import-exist');
		

		
		/* security array for valid filenames */
		$pmc_allowed_files = apply_filters( 'pmc_allowed_files', array( 
		  'pmc_file_one', 'pmc_file_two', 'pmc_file_three', 'pmc_file_four', 'pmc_file_five', 'pmc_file_six' , 'pmc_file_seven' , 'pmc_file_eight' , 'pmc_file_nine', 'pmc_file_ten'
		));
			
		if ( isset( $_POST['pmc_import_demo'] ) && !empty( $_POST['pmc_file'] ) ) {
		


			if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true);

			

				$class_wp_import = AQPB_PATH . 'assets/import/plugins/wordpress-importer.php';
				if ( file_exists( $class_wp_import ) ) {
					include $class_wp_import;
				}

				$class_widget_import = AQPB_PATH . 'assets/import/plugins/class-widget-data.php';
				if ( file_exists( $class_widget_import ) ) {
					include $class_widget_import;
				}
				
		
			
				if (pmc_woo() && PMC_SHOP){
					$single = array(
						'width' 	=> '700',	// px
						'height'	=> '600',	// px
						'crop'		=> 1 		// true
					);

					// Image sizes
					update_option( 'shop_single_image_size', $single ); 		// Single product image
				}
			
			
				$pmc_file = sanitize_file_name($_POST['pmc_file']);
				/*import xml*/
				if( get_option('pmc-import-exist') != 'true' ) {
					$importer = new PMC_import_WP();
					$theme_xml = AQPB_PATH . 'assets/import/xml/pmc_file_one.xml';
											
					$importer->fetch_attachments = true;
					ob_start();
					$importer->import($theme_xml);
					ob_end_clean();			
				}
				


				
				/*navigation*/								
					$locations = get_theme_mod( 'nav_menu_locations' ); 
					$menus = wp_get_nav_menus(); 
					
					if( is_array($menus) ) {
						foreach($menus as $menu) { // assign menus to theme locations
								$menu_items = wp_get_nav_menu_object($menu->term_id);							
								switch($menu_items->name){
									case 'Single Menu':
									$locations['pmcsinglemenu'] = $menu->term_id;	
									$locations['pmcrespmenu'] = $menu->term_id;
									$locations['pmcrespsinglemenu'] = $menu->term_id;		
									$locations['pmcscrollmenu'] = $menu->term_id;	
									$locations['pmcmainmenu'] = $menu->term_id;										
									break;										
									case 'Page Builder Menu':
										$locations['pagebuildermenu'] = $menu->term_id;											
									break;		
								}						
							
						}
					}
					
					
					set_theme_mod( 'nav_menu_locations', $locations );
					
					/*set home page*/
					
					$homepage 	= get_page_by_title( 'Home' );
					
					if( isset($homepage->ID) ) {
						update_option('show_on_front', 'page');
						update_option('page_on_front',  $homepage->ID); // Front Page
					}
										
				
				


				global $wp_rewrite;
				$wp_rewrite->set_permalink_structure('/%postname%/');
				$wp_rewrite->flush_rules();				
				
				/*widgets*/
				$class_widget_import = new Widget_Data_PMC();
				$class_widget_import->ajax_import_widget_data();				
					

				
				/*revolutin sldier*/

		
				$absolute_path = get_template_directory() . '/includes/import/revslider/';
				$path_to_file = explode( 'wp-content', $absolute_path );
				$path_to_wp = $path_to_file[0];
				
				
				require_once( $path_to_wp.'/wp-includes/functions.php');
				require_once( $path_to_wp.'/wp-admin/includes/file.php');
				
				$slider_array = array(
					'ecorecycle-fullwidth.zip',
					'ecorecycle_2.zip',
					'ecorecycle.zip',		
					'ecocatalogue.zip'
				);
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
				if(is_plugin_active( 'revslider/revslider.php')){	
				$slider = new RevSlider();
				 
					foreach($slider_array as $filepath) {
						
						$slider->importSliderFromPost(true, true, $absolute_path.$filepath);  
						
					}
				}

				
				
				update_option('pmc-import-exist', 'true');
				
				wp_redirect( admin_url( 'admin.php?page=pmc_importer&pmc-import-success=success' ) );
								
				
			
	
		
		}
		
	}
	
/* folder can be written*/
function pmc_check_folder( $path ) {
	if ( $path{strlen($path)-1}=='/' ) {
		return pmc_check_folder($path.uniqid(mt_rand()).'.tmp');
	}
	
	if (file_exists($path)) {
		if (!($f = @fopen($path, 'r+')))
			return false;
		fclose($f);
		return true;
	}
	
	if (!($f = @fopen($path, 'w')))
		return false;
	fclose($f);
	unlink($path);
	return true;
	
}

?>