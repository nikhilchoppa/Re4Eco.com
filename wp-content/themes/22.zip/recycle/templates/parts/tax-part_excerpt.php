<div class="post-excerpt entry-content"><?php the_excerpt() ?>
<a class="more-link button" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'recycle' );?></a> 
<div class="clearfix"></div>
</div>