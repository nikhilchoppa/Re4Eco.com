<?php
/**
 * Displays Posts (Classic display)
 *
 * Loop Name: Posts classic
 *
 * @package recycle
 * @since recycle 1.0
 */
?>
<?php get_template_part( 'templates/blog/content-blog-classic' );?>	