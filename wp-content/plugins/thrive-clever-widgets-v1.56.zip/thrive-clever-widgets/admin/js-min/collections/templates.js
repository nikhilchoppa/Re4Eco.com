/*! Thrive Clever Widgets 2020-08-13
* http://www.thrivethemes.com 
* Copyright (c) 2020 * Thrive Themes */
var tcw_app=tcw_app||{};!function(){tcw_app.Templates=Backbone.Collection.extend({model:tcw_app.Template})}(jQuery);