<meta name='twitter:card' content='summary_large_image'>

<meta name='twitter:title' content='<?php echo isset( $tc_title ) ? htmlspecialchars( $tc_title ) : ''; ?>' >

<meta name='twitter:description' content='<?php echo isset( $tc_description ) ? htmlspecialchars( $tc_description ) : '' ?>' >

<meta name='twitter:image' content='<?php echo isset( $tc_image ) ? $tc_image : '' ?>' >
