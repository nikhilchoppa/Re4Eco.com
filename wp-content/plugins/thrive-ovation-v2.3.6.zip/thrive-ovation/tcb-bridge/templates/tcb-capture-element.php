<div class="thrv_wrapper thrv_tvo_capture_testimonials tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'add', false, 'editor' ); ?>
		<?php echo __( 'Select Template', 'thrive-cb' ); ?>
	</span>
</div>
