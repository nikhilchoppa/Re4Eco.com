<div style="float: right;" class="tvo_comment_section_<?php echo $comment_id; ?>">
	<a href="javascript:void(0);" class="tvd-tooltipped tvo-comment-button" data-position="top"
	   data-tooltip="<?php echo __( 'Create testimonial from comment', TVO_TRANSLATE_DOMAIN ); ?>"
	   onclick="ThriveOvation.comments.addEditTestimonial(<?php echo $comment_id; ?>);">
		<span class="dashicons dashicons-plus"></span>
	</a>
</div>
