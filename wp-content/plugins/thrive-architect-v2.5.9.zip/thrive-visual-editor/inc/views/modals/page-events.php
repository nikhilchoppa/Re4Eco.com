<h2 class="tcb-modal-title"><?php echo __( 'Page Event Manager', 'thrive-cb' ) ?></h2>

<div class="page-events">
	<div class="modal-header"></div>
	<div id="events-form"></div>
</div>