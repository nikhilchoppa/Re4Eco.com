<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 5/3/2017
 * Time: 1:47 PM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv_disqus_comments">
	<div id="disqus_thread" data-disqus_identifier="368" data-disqus_shortname="<?php echo tve_get_comments_disqus_shortname(); ?>" data-disqus_url=""></div>
</div>
