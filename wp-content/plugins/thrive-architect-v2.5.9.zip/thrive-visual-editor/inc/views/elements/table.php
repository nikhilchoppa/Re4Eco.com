<div class="thrv_wrapper tcb-elem-placeholder thrv-table-placeholder">
	<span class="tcb-inline-placeholder-action with-icon"><?php tcb_icon( 'table', false, 'editor' ) ?><?php echo __( 'Insert table', 'thrive-cb' ) ?></span>
</div>
