<div class="control-grid full-width">
	<label for="v-yt-url">URL</label>
	<input type="text" data-setting="url" class="yt-url tve_provider_url" id="v-yt-url" placeholder="e.g. https://www.youtube.com/watch?v=oJ440S7gTBU">
</div>
<div class="yt-url-validate inline-message"></div>
