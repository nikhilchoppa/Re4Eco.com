<div class="control-grid full-width">
	<label for="v-eh-url">URL</label>
	<input type="text" data-setting="url" class="eh-url tve_provider_url" id="v-eh-url" placeholder="e.g. https://www.domain.com/video.extension">
</div>
<div class="eh-url-validate inline-message"></div>
