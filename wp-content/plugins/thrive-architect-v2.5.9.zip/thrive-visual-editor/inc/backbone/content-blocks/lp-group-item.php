<a href="javascript:void(0);" class="click lp-group" data-fn="filter" data-source="group" data-item="<#= group #>">
	<span><#= group #></span>
	<span class="lp-group-count"><#= counter #></span>
</a>
