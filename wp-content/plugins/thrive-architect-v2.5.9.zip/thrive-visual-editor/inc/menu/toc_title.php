<div id="tve-toc_title-component" class="tve-component" data-view="TOCTitle">
	<div class="dropdown-header" data-prop="docked">
		<div class="group-description"><?php echo __( 'Main Options', 'thrive-cb' ); ?></div>
		<i></i>
	</div>
	<div class="dropdown-content">
		<div class="tve-control" data-view="State"></div>
		<div class="tve-control hide-states" data-view="ShowIcon"></div>
		<div class="has-icon">
			<div class="tve-control hide-states" data-view="ModalPicker"></div>
			<div class="tve-control" data-view="IconColor"></div>
			<div class="tve-control hide-states" data-view="IconPlacement"></div>
			<div class="tve-control" data-view="IconSize"></div>
			<div class="tve-control show-state-expanded show-state-hover" data-view="RotateIcon"></div>
		</div>
	</div>
</div>
